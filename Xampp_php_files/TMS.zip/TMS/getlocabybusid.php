<?php 
 include "./config/config.php"; 
  $response = array();  
if(isTheseParametersAvailable(array('route'))){  
    $route = $_POST['route'];   
    
    
    $stmt = $conn->prepare("SELECT longitude, latitude, time FROM tbl_location WHERE busid = ? ");  
    $stmt->bind_param("s",$route);  
    $stmt->execute();  
    $stmt->store_result();  
    if($stmt->num_rows > 0){  
    $stmt->bind_result($longitude, $latitude, $time);   
    $stmt->fetch();  
    $user = array(  
            'latitude'=>$latitude,
            'longitude'=>$longitude,
            'time'=>$time
    );  
    $response['user'] = $user;   
 }  
 else{  
    $response['error'] = false;   
 }  
echo json_encode($response); 
}
 
function isTheseParametersAvailable($params){  
foreach($params as $param){  
 if(!isset($_POST[$param])){  
     return false;   
  }  
}  
return true;   
}  
 
?>
