<?php   
 include "./config/config.php"; 
  $response = array();  
  if(isset($_GET['apicall'])){  
  switch($_GET['apicall']){  
  case 'signup':  
    if(isTheseParametersAvailable(array('sid','uname','fname','pass','phone','dept','pick','section','batch','role', 'codename','designation'))){  
    $fname = $_POST['fname'];   
    $uname = $_POST['uname'];   
    $pick = $_POST['pick'];   
    $pass = $_POST['pass'];  
    $sid = $_POST['sid'];   
    $phone = $_POST['phone'];   
    $section = $_POST['section'];   
    $role = $_POST['role'];   
    $dept = $_POST['dept'];   
    $batch = $_POST['batch'];   
    $codename = $_POST['codename'];   
    $designation = $_POST['designation'];   
    
    
    $stmt = $conn->prepare("SELECT uname FROM tbl_user WHERE uname = ?");  
    $stmt->bind_param("s", $uname);  
    $stmt->execute();  
    $stmt->store_result();  
   
    if($stmt->num_rows > 0){  
        $response['error'] = true;  
        $response['message'] = 'User Name Is Already Registered';  
        $stmt->close();  
    }  
    else{  
        $stmt = $conn->prepare("INSERT INTO tbl_user (uname, fname, sid, pass, phone, section, role, dept, batch, pick, codename, designation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");  
        $stmt->bind_param("ssssssssssss", $uname, $fname, $sid, $pass, $phone, $section, $role, $dept, $batch, $pick, $codename, $designation);  
   
        if($stmt->execute()){  
            $stmt = $conn->prepare("SELECT uname, fname, sid, pass, phone, section, role, dept, batch, pick, codename, designation FROM tbl_user WHERE uname = ?");   
            $stmt->bind_param("s",$uname);  
            $stmt->execute();  
            $stmt->bind_result($uname, $fname, $sid, $pass, $phone, $section, $role, $dept, $batch, $pick, $codename,  $designation);  
            $stmt->fetch();  
   
            $user = array(  
            'sid'=>$sid,
            'uname'=>$uname,   
            'fname'=>$fname,  
            'phone'=>$phone,  
            'section'=>$section,  
            'role'=>$role,  
            'dept'=>$dept,  
            'batch'=>$batch, 
            'pick'=>$pick,  
            'designation'=>$designation,
            'codename'=>$codename, 
            'pass'=>$pass  
            
            );  
   
            $stmt->close();  
   
            $response['error'] = false;   
            $response['message'] = 'User registered successfully';   
            $response['user'] = $user;   
        }  
    }  
   
}  
else{  
    $response['error'] = true;   
    $response['message'] = 'required parameters are not available';   
}  
break;   
case 'login':  
  if(isTheseParametersAvailable(array('uname', 'pass'))){  
    $uname = $_POST['uname'];  
    $pass = $_POST['pass'];   
   
    $stmt = $conn->prepare("SELECT uname, fname, sid, pass, phone, section, role, dept, batch, pick, codename, designation FROM tbl_user WHERE uname = ? AND pass = ?");  
    $stmt->bind_param("ss",$uname, $pass);  
    $stmt->execute();  
    $stmt->store_result();  
    if($stmt->num_rows > 0){  
    $stmt->bind_result($uname, $fname, $sid, $pass, $phone, $section, $role, $dept, $batch, $pick, $codename,  $designation);   
    $stmt->fetch();  
    $user = array(  
            'sid'=>$sid,
            'uname'=>$uname,   
            'fname'=>$fname,  
            'phone'=>$phone,  
            'section'=>$section,  
            'role'=>$role,  
            'dept'=>$dept,  
            'batch'=>$batch, 
            'pick'=>$pick,  
            'designation'=>$designation,
            'codename'=>$codename, 
            'pass'=>$pass  
    );  
   
    $response['error'] = false;   
    $response['message'] = 'Login successfull';   
    $response['user'] = $user;   
 }  
 else{  
    $response['error'] = false;   
    $response['message'] = 'Invalid username or password';  
 }  
}  
break;  
case 'update':  
    if(isTheseParametersAvailable(array('sid','uname','fname','pass','phone','dept','pick','section','batch','role', 'codename','designation'))){  
    $fname = $_POST['fname'];   
    $uname = $_POST['uname'];   
    $pick = $_POST['pick'];   
    $pass = $_POST['pass'];  
    $sid = $_POST['sid'];   
    $phone = $_POST['phone'];   
    $section = $_POST['section'];   
    $role = $_POST['role'];   
    $dept = $_POST['dept'];   
    $batch = $_POST['batch'];   
    $codename = $_POST['codename'];   
    $designation = $_POST['designation'];   
    
    $query = "UPDATE tbl_user SET sid='$sid', role ='$role', uname='$uname', fname ='$fname', pass='$pass', phone ='$phone', dept ='$dept', pick ='$pick', section ='$section', batch ='$batch', codename ='$codename', designation ='$designation' WHERE uname = '$uname'";
     
        if($stmt = mysqli_query($conn, $query)){  
            $stmt = $conn->prepare("SELECT uname, fname, sid, pass, phone, section, role, dept, batch, pick, codename, designation FROM tbl_user WHERE uname = ?");   
            $stmt->bind_param("s",$uname);  
            $stmt->execute();  
            $stmt->bind_result($uname, $fname, $sid, $pass, $phone, $section, $role, $dept, $batch, $pick, $codename,  $designation);  
            $stmt->fetch();  
   
            $user = array(  
            'sid'=>$sid,
            'uname'=>$uname,   
            'fname'=>$fname,  
            'phone'=>$phone,  
            'section'=>$section,  
            'role'=>$role,  
            'dept'=>$dept,  
            'batch'=>$batch, 
            'pick'=>$pick,  
            'designation'=>$designation,
            'codename'=>$codename, 
            'pass'=>$pass  
            
            );  
   
            $stmt->close();  
   
            $response['error'] = false;   
            $response['message'] = 'User registered successfully';   
            $response['user'] = $user;   
        }  
    
   
}  
else{  
    $response['error'] = true;   
    $response['message'] = 'required parameters are not available';   
}  
break;    
default:   
 $response['error'] = true;   
 $response['message'] = 'Invalid Operation Called';  
}  
}  
else{  
 $response['error'] = true;   
 $response['message'] = 'Invalid API Call';  
}  
echo json_encode($response);  
function isTheseParametersAvailable($params){  
foreach($params as $param){  
 if(!isset($_POST[$param])){  
     return false;   
  }  
}  
return true;   
}  
 
