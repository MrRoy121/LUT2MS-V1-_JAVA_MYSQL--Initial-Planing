<?php   

include "./config/config.php"; 
     $products = array(); 
 if(isTheseParametersAvailable(array('route','date'))){  
    $date = $_POST['date'];   
    $route = $_POST['route'];   
    
    
     $stmt = $conn->prepare("SELECT busid, time FROM tbl_allowcatedbus where route = ? AND datee =?");
     $stmt->bind_param("ss",$route,$date); 
     $stmt->execute();
     $stmt->bind_result($busid, $time);
     while($stmt->fetch()){
		 $temp = array();
		 $temp['time'] = $time; 
		 $temp['busid'] = $busid; 
		 array_push($products, $temp);
		 }
}   
	echo json_encode($products);
function isTheseParametersAvailable($params){  
foreach($params as $param){  
 if(!isset($_POST[$param])){  
     return false;   
  }  
}  
return true;   
}  
 
