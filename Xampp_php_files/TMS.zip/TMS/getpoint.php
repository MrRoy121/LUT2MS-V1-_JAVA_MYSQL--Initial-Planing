<?php   

include "./config/config.php"; 
     $sql = "SELECT name FROM stopppage";
	$result = ($conn->query($sql));
    $row = []; 
  $row = $result->fetch_all(MYSQLI_ASSOC); 
     
   
	echo json_encode($row);
function isTheseParametersAvailable($params){  
foreach($params as $param){  
 if(!isset($_POST[$param])){  
     return false;   
  }  
}  
return true;   
}  
 
