<?php   
 include "./config/config.php"; 
  $response = array();   
   if(isTheseParametersAvailable(array('time','date','uname','route'))){  
    $time = $_POST['time'];   
    $date = $_POST['date'];   
    $uname = $_POST['uname'];  
    $route = $_POST['route'];   
   
    $stmt = $conn->prepare("SELECT date FROM tbl_requestseat WHERE uname = ? AND date = ?");  
    $stmt->bind_param("ss", $uname, $date);  
    $stmt->execute();  
    $stmt->store_result();  
   
	
    if($stmt->num_rows > 0){  
        $response['error'] = true;  
        $response['message'] = 'You Already Booked for the day!!';  
        $stmt->close();  
    }  
    else{  
        $stmt = $conn->prepare("INSERT INTO tbl_requestseat (time, date, uname, route) VALUES (?, ?, ?, ?)");  
        $stmt->bind_param("ssss", $time, $date, $uname, $route);  
   
        if($stmt->execute()){  
            $stmt->close();  
            $response['error'] = false;   
            $response['message'] = 'Seat Requested Successfully';   
            $response['user'] = $user;   
        }  
     }
}  
else{  
    $response['error'] = true;   
    $response['message'] = 'required parameters are not available';   
}  

echo json_encode($response);  
function isTheseParametersAvailable($params){  
foreach($params as $param){  
 if(!isset($_POST[$param])){  
     return false;   
  }  
}  
return true;   
}  
 
